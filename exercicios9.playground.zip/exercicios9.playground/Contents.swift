import UIKit
import Foundation

class Empregado {
    var nome: String
    var sobrenome: String
    var numberempregado: Int
    var fullName: String { "\(nome)  \(sobrenome) funcionario: \(numberempregado)"}
    
    init(nome: String, sobrenome: String, numberFuncionario: Int) {
        self.nome = nome
        self.sobrenome = sobrenome
        self.numberempregado = numberFuncionario
    }
    
}


var empregado01 = Empregado(nome: "Pedro",
                            sobrenome: "Augusto",
                            numberFuncionario: 1)

var empregado02 = Empregado(nome: "Jorge",
                            sobrenome: "DaVilla",
                            numberFuncionario: empregado01.numberempregado + 1)
empregado01.fullName
empregado02.fullName
print(empregado01.fullName)
print(empregado02.fullName)
